$(document).ready(function() {
     $(".read_button a").click(function(){
        alert("click");
        //jQuery('#navigation #primary ul').removeClass('menu-list');

       $("#navigation ul").css("color","red");
    });
});