See the setup instructions at http://www.drupal.org/project/bootstrap_agency

Modifications for Drupal are  (c) 2015 Joao Ventura (https://www.drupal.org/u/jcnventura)

This theme is licensed under the GPL, and is a derived work from the following sources:

Drupal bootstrap base theme, available under the GPLv2 at
http://www.drupal.org/project/bootstrap

bootstrap_agency_* LESS source code and Javascript from Start Bootstrap's Agency template is 
(c) 2013-2015 Iron Summit Media Strategies,LLC, released under the [Apache 2.0] license
http://startbootstrap.com/template-overviews/agency/

which is based on the freely available PSD "Golden" by Mathavan Java at FreebiesXpress:
http://freebiesxpress.com/gallery/golden-free-one-page-web-template/

header-bg.jpg is (c) Vadim Sherbakov (www.madebyvadim.com), under CC0/Public Domain in Unsplash
http://unsplash.s3.amazonaws.com/batch%203/www.madebyvadim.com.jpg

map-image.png is (c) Jayhan Sim, licensed freely for use on both personal and commercial projects
http://www.jay-han.com/2008/01/06/dotted-world-map-vector-resource-free-download
